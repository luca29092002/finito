﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Threading;




namespace Alternanza_Disk
{
    public partial class Form1 : Form
    {
        Data ricerca = new Data();
        public Form1()
        {

            
            InitializeComponent();
            #region links
            linkLabel1.Hide();
            panel3.Hide();
            linkLabel2.Hide();
            linkLabel3.Hide();
            linkLabel4.Hide();
            linkLabel5.Hide();
            label2.Hide();
            bianco.Hide();
            rosa.Hide();
            giallo.Hide();
            textBox1.Hide();
            button2.Hide();
            verde.Hide();
            listBox1.Hide();
            richTextBox1.Hide();
            MODOFF.Hide();

            #endregion

        }
        private void searchButton_Click(object sender, EventArgs e)
        {
            
            #region links
            linkLabel1.Hide();
            linkLabel2.Hide();
            linkLabel3.Hide();
            linkLabel4.Hide();
            linkLabel5.Hide();

            #endregion
            if (searchText.Text == " " || searchText.Text == "")
                MessageBox.Show("Inserire ricerca");
            else
            {
                ricerca.elementoRicerca = searchText.Text;
                searchText.Text = "Sto cercando ...";
                Ricerca();
                #region links
                if (Data.controlloConnessione())
                {
                    linkLabel1.Text = ricerca.urls[0];
                    linkLabel2.Text = ricerca.urls[1];
                    linkLabel3.Text = ricerca.urls[2];
                    linkLabel4.Text = ricerca.urls[3];
                    linkLabel5.Text = ricerca.urls[4];

                    linkLabel1.Show();
                    linkLabel2.Show();
                    linkLabel3.Show();
                    linkLabel4.Show();
                    linkLabel5.Show();
                }
                #endregion
            }
        }
        public void Ricerca()
        {
          Jump:
            if (Data.controlloConnessione() == false)                                                                           //Nel caso in cui la funzione controlloConnessione restituisca un valore false ovvero assenza di connessione il message box apparirà
            {
                MessageBox.Show("Connessione assente, utilizzare funzionalità offline ");
                searchText.Text = "";
            }
            else
            {
                WebRequest request = WebRequest.Create("https://www.google.com/search?q=" + ricerca.elementoRicerca);      //La richiesta viene inoltrata a https://www.google.com/search?q=, essendo il modello principale per la ricerca, attaccandogli cioò che l'utente vuole cercare
                request.Credentials = CredentialCache.DefaultCredentials;
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                //MessageBox.Show(((HttpWebResponse)response).StatusDescription);
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();
                StreamWriter a = new StreamWriter("output.txt", false);
                a.Write(responseFromServer);                                                                                   //Dopo il processo di interrogazione a google la risposta viene scritta sul file di testo output.txt
                a.Close();
                StreamReader r = new StreamReader("output.txt");
                string rs = r.ReadToEnd();
                r.Close();
                if(!rs.Contains("<cite>"))
                {
                    goto Jump;
                }
                string[] urls = ricercaUrl();                                                                                 //viene richiamata la funzione ricercaUrl()
                searchText.Text = "";
                ricerca.urls.Clear();
                #region copiaUrl
                
                for (int i = 1; i < 6; i++)
                    ricerca.urls.Add(urls[i]);
                
                #endregion
            }
        }
        public string[] ricercaUrl()
        {
            int i = 1;
            var a = '"';
            string[] links = new string[15];                                                                                    //vettore di stringhe, contenente i link
            int counter = 6;
            int x = default(int);
            StreamReader r = new StreamReader("output.txt");                                                                    //links.txt è il file di testo contenente i link
            while (x < counter)
            {
                try
                {
                    bool c = default(bool);
                    string controllo = r.ReadLine();
                    if (controllo.Contains("<cite>"))                                                                           //Il controllo funziona in base alla presenza di url?q= all'interno di una riga di codice usiamo questa logica due volte, e infine nella stringa splittata creiamo una Substring che parte dalla dicitura http presente in ogni link utile già filtrato
                    {
                        string[] y = controllo.Split(a, a);
                        foreach (string s in y)
                            if (s.Contains("<cite>") && i < 16)
                            {
                                int indexE;
                                string str = "";
                                int indexF = s.LastIndexOf("http");
                                indexE = s.LastIndexOf("/") - 6;                                                               //Eccezione generale
                                try
                                {
                                    str = s.Substring(indexF, indexE);
                                }
                                catch { }
                                str = str.Replace("<b>", "");
                                str = str.Replace("</b>", "");
                                str = str.Replace("</cite>", "");
                                str = str.Replace("</", "");
                                str = str.Replace("�", "à");
                                if (str.Contains("/.../"))
                                {
                                    try
                                    {
                                        HttpWebRequest request = WebRequest.Create(str) as HttpWebRequest;
                                        request.Method = "HEAD";
                                        HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                                        response.Close();
                                    }
                                    catch { c = true; }
                                }
                                if (c == false && str != "")
                                {
                                    links[i] = str;
                                    i++;
                                    x++;
                                }
                            }
                    }

                }
                catch { x++; i++; }                                                                                                      //Metodo utilizzato per ricerca l'url nel file di testo "output.txt"
            }
            r.Close();
            return links;
        }
        #region Grafica
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();



        private void move(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void a(object sender, EventArgs e)
        {
            
        }

        private void shutdown_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

      

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel3.Text);
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel4.Text);
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel5.Text);
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel2.Text);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel1.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            label2.Hide();
            panel3.Hide();
            bianco.Hide();
            rosa.Hide();
            giallo.Hide();
            verde.Hide();
            label1.Hide();
            searchText.Hide();
            searchButton.Hide();
            linkLabel1.Hide();
            textBox1.Hide();
            button2.Hide();
            linkLabel2.Hide();
            linkLabel3.Hide();
            linkLabel4.Hide();
            linkLabel5.Hide();
            listBox1.Show();
            richTextBox1.Show();
            MODOFF.Show();
            panel3.Hide();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            label2.Show();
            bianco.Show();
            panel3.Show();
            rosa.Show();
            giallo.Show();
            verde.Show();
            label1.Hide();
            searchText.Hide();
            searchButton.Hide();
            linkLabel1.Hide();
            linkLabel2.Hide();
            linkLabel3.Hide();
            linkLabel4.Hide();
            textBox1.Hide();
            button2.Hide();
            linkLabel5.Hide();
            MODOFF.Hide();
            listBox1.Hide();
            richTextBox1.Hide();
            



        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        
        
       
        private void Form1_Load(object sender, EventArgs e)
        {
            
         


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Show();
            panel3.Hide();
            searchText.Show();
            searchButton.Show();
            label2.Hide();
            textBox1.Hide();
            button2.Hide();
            bianco.Hide();
            rosa.Hide();
            giallo.Hide();
            verde.Hide();
            if (linkLabel1.Text != "linkLabel1")
            {
                linkLabel1.Show();
                linkLabel2.Show();
                linkLabel3.Show();
                linkLabel4.Show();
                linkLabel5.Show();
            }
            listBox1.Hide();
            richTextBox1.Hide();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Hide();
            panel3.Hide();
            searchText.Hide();
            searchButton.Hide();
            label2.Hide();
            bianco.Hide();
            rosa.Hide();
            giallo.Hide();
            verde.Hide();
            listBox1.Hide();
            textBox1.Hide();
            richTextBox1.Hide();
            MODOFF.Hide();
            textBox1.Show();
            button2.Show();

           

        }
       

        private void bianco_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            button1.BackColor = Color.White;
            label2.BackColor = Color.White;
            button3.BackColor = Color.White;
            button4.BackColor = Color.White;
            label1.BackColor = Color.White;
            panel1.BackColor = Color.White;
            minimize.BackColor = Color.White;
            shutdown.BackColor = Color.White;
            richTextBox1.BackColor = Color.White;
            listBox1.BackColor = Color.White;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void searchText_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void rosa_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Pink;
            button1.BackColor = Color.Pink;
            label2.BackColor = Color.Pink;
            button3.BackColor = Color.Pink;
            button4.BackColor = Color.Pink;
            label1.BackColor = Color.Pink;
            panel1.BackColor = Color.Pink;
            richTextBox1.BackColor = Color.Pink;
            listBox1.BackColor = Color.Pink;
        }

        private void giallo_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
            button1.BackColor = Color.Yellow;
            label2.BackColor = Color.Yellow;
            button3.BackColor = Color.Yellow;
            button4.BackColor = Color.Yellow;
            label1.BackColor = Color.Yellow;
            panel1.BackColor = Color.Yellow;
            minimize.BackColor = Color.Yellow;
            shutdown.BackColor = Color.Yellow;
            richTextBox1.BackColor = Color.Yellow;
            listBox1.BackColor = Color.Yellow;
        }

        private void verde_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.GreenYellow;
            button1.BackColor = Color.GreenYellow;
            label2.BackColor = Color.GreenYellow;
            button3.BackColor = Color.GreenYellow;
            button4.BackColor = Color.GreenYellow;
            label1.BackColor = Color.GreenYellow;
            panel1.BackColor = Color.GreenYellow;
            minimize.BackColor = Color.GreenYellow;
            shutdown.BackColor = Color.GreenYellow;
            richTextBox1.BackColor = Color.GreenYellow;
            listBox1.BackColor = Color.GreenYellow;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #region  Parte offline
        private void listBox1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                if (listBox1.SelectedItem.ToString() == "Attacco DDOS")
                {
                    richTextBox1.Text = "La locuzione Denial of Service (in italiano letteralmente negazione del servizio abbreviato in DoS) nel campo della sicurezza informatica indica un malfunzionamento dovuto ad un attacco informatico in cui si fanno esaurire deliberatamente le risorse di un sistema informatico che fornisce un servizio ai client, ad esempio un sito web su un web server, fino a renderlo non più in grado di erogare il servizio ai client richiedenti.In un attacco denial-of - service distribuito(attacco DDoS - Distributed Denial of Service), il traffico in entrata che inonda la vittima proviene da molte fonti diverse. Ciò rende effettivamente impossibile fermare l'attacco semplicemente bloccando una singola fonte. L'esempio in analogia è quello di un gruppo di persone che affollano la porta d'ingresso o il cancello di un negozio o di un'azienda, e non consentendo alle parti legittime di entrare nel negozio o nel business, interrompendo le normali operazioni.Oltre al senso primario di denial of service come azione deliberata ci si può riferire ad esso come azione accidentale, in seguito per esempio ad una errata configurazione,o come nel caso dell'effetto Slashdot. ";
                }
                if (listBox1.SelectedItem.ToString() == "Blackout")
                {
                    richTextBox1.Text = "Un black-out viene considerato tale quando i suoi effetti provocano problemi o danni nella disponibilità e nel funzionamento di servizi elettrici (per esempio trasporti, telecomunicazione, riscaldamento, sistemi di sicurezza e reti informatiche). Il distacco della corrente elettrica può essere causato volontariamente (da parte del gestore della rete) oppure involontariamente, per esempio a causa di problemi a centrali o linee, sovraccarico della rete (consumo eccessivo rispetto all'effettiva capacità di produzione) oppure cortocircuiti.La definizione di black-out si applica al caso in cui l'elettricità sia totalmente assente per un lungo periodo; qualora sia presente ma con un livello inferiore al valore normale il guasto è detto «brownout», mentre un'interruzione momentanea (da pochi millisecondi a qualche secondo, comunque sufficiente per essere avvertita) è chiamata «dropout».I sistemi collegati a linee elettriche trifase possono essere soggetti a brownout quando uno o più fasi sono assenti, hanno una tensione insufficiente o non correttamente in fase; tali problemi possono danneggiare, in particolare, un motore elettrico.Alcuni abbassamenti di tensione sono causati intenzionalmente dal fornitore, per prevenire il distacco completo dell'energia (diminuendo la tensione, i carichi risultano generalmente alleggeriti). Il <<rolling blackout>> è il termine usato per indicare una forma di turnazione controllata dell'erogazione tra i vari distretti di utenze, evitando così un blackout di vaste aree.L'interruzione di energia elettrica risulta particolarmente pericolosa per gli ospedali, essendo molte utenze interne (tra cui i macchinari per il mantenimento delle funzioni vitali e le sale operatorie) dipendenti dall'elettricità. In ragione di tali rischi, molti strutture possiedono generatori elettrici di emergenza(solitamente alimentati da motori a gasolio) configurati per avviarsi appena ha luogo l'interruzione di corrente; i gruppi di continuità evitano che l'elettricità venga a mancare, anche durante gli istanti in cui il motore a gasolio si avvia. I generatori di emergenza sono presenti anche in altre strutture di vitale importanza, come le linee di produzione industriale non interrompibil, i sistemi di sicurezza delle centrali.Le centrali telefoniche e le reti telematiche hanno, di norma, gruppi di batterie in tampone per il backup e - in alcuni casi -anche connessioni ad un motogeneratore a gasolio per l'assenza prolungata di energia.";

                }
                if (listBox1.SelectedItem.ToString() == "Internet")
                {
                    richTextBox1.Text = "Internet è una rete ad accesso pubblico che connette vari dispositivi o terminali in tutto il mondo. Dalla sua nascita rappresenta il principale mezzo di comunicazione di massa, che offre all'utente una vasta serie di contenuti potenzialmente informativi e di servizi.Si tratta di un'interconnessione globale tra reti informatiche di natura e di estensione diversa, resa possibile da una suite di protocolli di rete comune chiamata <<TCP / IP>> dal nome dei due protocolli principali, il TCP e l'IP, che costituiscono la <<lingua>> comune con cui i computer connessi a Internet (gli host) sono interconnessi e comunicano tra loro a un livello superiore indipendentemente dalla loro sottostante architettura hardware e software, garantendo così l'interoperabilità tra sistemi e sottoreti fisiche diverse.L'avvento e la diffusione di Internet e dei suoi servizi hanno rappresentato una vera e propria rivoluzione tecnologica e socio-culturale dagli inizi degli anni novanta (assieme ad altre invenzioni come i telefoni cellulari e l GPS) nonché uno dei motori dello sviluppo economico mondiale nell'ambito delle Tecnologie dell'Informazione e della Comunicazione (ICT).In quanto rete di telecomunicazione, come diffusione è seconda solo alla rete telefonica generale, anch'essa di diffusione mondiale e ad accesso pubblico, ma ancora più <<capillare>> di Internet.";
                }
                if (listBox1.SelectedItem.ToString() == "Emergenza incendio")
                {
                    richTextBox1.Text = "- comportarsi secondo le procedure pre-stabilite (ove esistono)/n -se si tratta di un principio di incendio valutare la situazione determinando se esiste la possibilità di estinguere immediatamente l’incendio con i mezzi a portata di mano/n -non tentare di iniziare lo spegnimento con i mezzi portatili se non si è sicuri di riuscirvi/n -dare immediatamente l’allarme/n -intercettare le alimentazioni di gas, energia elettrica, ecc.../n -limitare la propagazione del fumo e dell’incendio chiudendo le porte di accesso/ compartimenti /n -iniziare l’opera di estinzione solo con la garanzia di una via di fuga sicura alle proprie spalle e con l’assistenza di altre persone /n -accertarsi che l’edificio venga evacuato/n -se non si riesce a mettere sotto controllo l’incendio in breve tempo, portarsi all’esterno dell’edificio e dare le adeguate indicazioni alle squadre dei Vigili del Fuoco.";
                }
                if (listBox1.SelectedItem.ToString() == "Indirizzo IP")
                {
                    richTextBox1.Text = "Un indirizzo IP (dall'inglese Internet Protocol address) - in informatica e nelle telecomunicazioni - è un'etichetta numerica che identifica univocamente un dispositivo detto host collegato a una rete informatica che utilizza l'Internet Protocol come protocollo di rete.Viene assegnato a una interfaccia (ad esempio una scheda di rete) che identifica l'host di rete, che può essere un personal computer, un palmare, uno smartphone, un router, o anche un elettrodomestico. Va considerato, infatti, che un host può contenere più di una interfaccia: ad esempio, un router ha diverse interfacce (minimo due) per ognuna delle quali occorre un indirizzo.";
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public int j = 1;
        #endregion
        #region Chat
        private void button2_Click(object sender, EventArgs e)
        {
            string elemento = textBox1.Text;
            try
            {
                elemento.Remove(6);
            }
            catch
            {
                MessageBox.Show("scrivere cerca");
            }
            if (textBox1.Text.Contains("cerca"))
            {

            }
            if(elemento.ToLower().Contains("apri"))
            {
                if(textBox1.Text.ToLower().Contains("google"))
                System.Diagnostics.Process.Start("https://www.google.com");
                if (textBox1.Text.ToLower().Contains("hotmail"))
                    System.Diagnostics.Process.Start("https://www.hotmail.com");
                if (textBox1.Text.ToLower().Contains("gmail"))
                 System.Diagnostics.Process.Start("https://www.gmail.com");
                if (elemento.ToLower().Contains("google maps"))
                    System.Diagnostics.Process.Start("https://www.google.it/maps");
                if (elemento.ToLower().Contains("libero"))
                    System.Diagnostics.Process.Start("https://www.libero.it");
                if (elemento.ToLower().Contains("instagram"))
                    System.Diagnostics.Process.Start("https://www.instagram.com");
                if (elemento.ToLower().Contains("facebook"))
                    System.Diagnostics.Process.Start("https://www.facebook.com");
                if (elemento.ToLower().Contains("twitter"))
                    System.Diagnostics.Process.Start("https://wwww.twitter.com");

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
#endregion
